      character VERSION*(*)
      parameter ( VERSION='tomo_sp_cu_s, v1.2.2_.1')
